import sqlite3
from datetime import datetime
import os
import sys
import random

#CommandLine arguments (between single quotes):
# 1 = channel
# 2 = title
# 3 = description

#--- CONFIGURATION ---
DBName = "/config/www/epg/epg_data.db"
HTMLFilelocation = "/config/www/epg/"
LOGOFolder = "logos/"
HA_BaseURL = "https://192.168.123.88:8123/local/epg/"
HA_LinkURL = "https://192.168.123.88:8123/"
#--- CONNECT TO SQLITE3 DB ---
conn = sqlite3.connect(DBName)

#--- CREATE FILENAME TO STORER SEARCH-RESULTS IN UNIQUE HTML FILE ---
StrFile = ""
x = range(1,16)
for n  in x:
  r = random.randint(66,89)
  StrFile = StrFile + str(chr(r))

#--- CHANGE search_url in DB ---
conn.execute("DELETE FROM epg_search_url")
sqldata = HA_BaseURL + StrFile + ".html"
sqldata = [sqldata]
sql = "INSERT INTO epg_search_url (search_url) VALUES (?)"
conn.execute(sql,sqldata)
conn.commit()

#--- GET PARAMETERS FROM epg_search TABLE ---
tmpcur = conn.execute("SELECT channel,title,description FROM epg_search")
for tmprow in tmpcur:
  searchchannel = tmprow[0]
  searchtitle = tmprow[1]
  searchdescription = tmprow[2]

#--- start writing search.html file ---
f = open(HTMLFilelocation + StrFile + ".html","w")
f.write("<HTML>                                                                                       \n" \
      + "  <script src='https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>   \n" \
      + "  <script src='/js/my.js'></script>                                                          \n" \
      + "  <SCRIPT language='javascript' type='text/javascript'></script>                             \n" \
      + "  <SCRIPT>                                                                                   \n" \
      + "    $(document).ready(function ()                                                            \n" \
      + "    {                                                                                        \n" \
      + "      $('#leftx').scroll(function ()                                                         \n" \
      + "       {                                                                                     \n" \
      + "         $('#right').scrollTop($('#leftx').scrollTop());                                     \n" \
      + "       });                                                                                   \n" \
      + "       $('#right').scroll(function ()                                                        \n" \
      + "        {                                                                                    \n" \
      + "	  $('#leftx').scrollTop($('#right').scrollTop());                                     \n" \
      + "	  $('#righttop').scrollLeft($('#right').scrollLeft());                                \n" \
      + "        });                                                                                  \n" \
      + "       $('#righttop').scroll(function ()                                                     \n" \
      + "        {                                                                                    \n" \
      + "	  $('#right').scrollLeft($('#righttop').scrollLeft());                                \n" \
      + "       });                                                                                   \n" \
      + "  });                                                                                        \n" \
      + " </SCRIPT>                                                                                   \n" \
      + "<HEAD>                                                                                       \n" \
      + "<STYLE>                                                                                      \n" \
      + "  #topx {                                                                                    \n" \
      + "          width: 1335px;                                                                     \n" \
      + "          height: 680px;                                                                     \n" \
      + "          float: left;                                                                       \n" \
      + "          clear: both;                                                                       \n" \
      + "         }                                                                                   \n" \
      + "  #rightx {                                                                                  \n" \
      + "          width: 100%;                                                                       \n" \
      + "          height: 680px;                                                                     \n" \
      + "          float: right;                                                                      \n" \
      + "          text-align: left;                                                                  \n" \
      + "          overflow-y: auto;                                                                  \n" \
      + "          right: 0;                                                                          \n" \
      + "         }                                                                                   \n" \
      + "  table {                                                                                    \n" \
      + "         background-color: transparent;                                                      \n" \
      + "         border-spacing: 1px;                                                                \n" \
      + "        }                                                                                    \n" \
      + "  th, td {                                                                                   \n" \
      + "          padding: 5px;                                                                      \n" \
      + "          text-align:left;                                                                   \n" \
      + "          color: white;                                                                      \n" \
      + "          border: 0px;                                                                       \n" \
      + "     }                                                                                       \n" \
      + "  body {                                                                                     \n" \
      + "        background-image: url('iptv.jpg');                                                   \n" \
      + "       }                                                                                     \n" \
      + "  tr {                                                                                       \n" \
      + "      background-color:rgba(64,64,64,80%);                                                   \n" \
      + "      color: white;                                                                          \n" \
      + "      padding: 5px;                                                                          \n" \
      + "     }                                                                                       \n" \
      + "  #even {                                                                                    \n" \
      + "          background-color:rgba(96,96,96,80%);                                               \n" \
      + "          color: white;                                                                      \n" \
      + "          padding: 5px;                                                                      \n" \
      + "        }                                                                                    \n" \
      + "  #titel {                                                                                   \n" \
      + "          height:50px;                                                                       \n" \
      + "          color: white;                                                                      \n" \
      + "          padding: 5px;                                                                      \n" \
      + "          background-color: rgba(96,0,0,80%);                                                \n" \
      + "         }                                                                                   \n" \
      + "  a:link    {color: white; text-decoration: none;}                                           \n" \
      + "  a:visited {color: white; text-decoration: none;}                                           \n" \
      + "  a:hover   {color: white; text-decoration: none;}                                           \n" \
      + "  a:active  {color: white; text-decoration: none;}                                           \n" \
      + "</STYLE>                                                                                     \n" \
      + "</HEAD>                                                                                      \n" \
      + "</div>                                                                                       \n" \
      + "<div id='topxx'>                                                                             \n")
#--- TIMELINE ---
f.write("   <div id='rightx'>                                                                         \n" )
cursor = conn.execute("SELECT dta.channel,dta.start,dta.stop,dta.title,dta.subtitle,dta.description,dta.episode,ch.logoname,dta.recid  FROM epg_data as dta, epg_channel as ch WHERE dta.channel LIKE '%"+ searchchannel + "%' AND dta.title LIKE '%" + searchtitle + "%' AND dta.description LIKE '%"+ searchdescription +"%' and dta.channel = ch.channelname  ORDER BY dta.start,dta.channel") 
#sql = "SELECT dta.channel,dta.start,dta.stop,dta.title,dta.subtitle,dta.description,dta.episode,ch.logoname,dta.recid  FROM epg_data as dta, epg_channel as ch WHERE dta.channel LIKE '%"+ searchchannel + "%' AND dta.title LIKE '%" + searchtitle + "%' AND dta.description LIKE '%"+ searchdescription +"%' and dta.channel = ch.channelname  ORDER BY dta.start,dta.channel"
#print(sql)
counter = 0
for row in cursor:
  dta_channel = row[0]
  dta_channel = dta_channel.strip()
  posx = dta_channel.find(".")
  dta_channel = dta_channel[:posx]
  dta_start = row[1]
  dta_stop = row[2]
  dta_title = row[3]
  dta_subtitle = row[4]
  dta_description = row[5]
  dta_episode = row[6]
  dta_logo = row[7]
  dta_recid = row[8]
  starttime = dta_start[8:10] + ":" + dta_start[10:12]
  stoptime = dta_stop[8:10] + ":" + dta_stop[10:12]
  startdate = dta_start[:8]
  stopdate = dta_stop[:8]
  hourstop = int(dta_stop[8:10])
  minutestop = int(dta_stop[10:12])
  hourstart = int(dta_start[8:10])
  minutestart = int(dta_start[10:12])
  if startdate == stopdate:
    difference = datetime.strptime(str(hourstop) + ":" + str(minutestop),"%H:%M") - datetime.strptime(str(hourstart) + ":" + str(minutestart),"%H:%M") 
    totalminutes = difference.total_seconds() / 60
    houradd = 0
    minuteadd = 0
  else:
    difference = datetime.strptime(str(hourstart) + ":" + str(minutestart), "%H:%M") - datetime.strptime( "00:00" , "%H:%M")
    totalminutes = 1440 - (difference.total_seconds() / 60)
    houradd = hourstop
    minuteadd =minutestop
  totalminutes = totalminutes + minuteadd + (houradd * 60)
  totalhours = int(totalminutes // 60)
  totalminutes = totalminutes - (totalhours * 60)
  totalminutes = int(totalminutes)
  strtime = str(totalhours) + "u " + str(totalminutes) + "m"
  strdate = startdate[6:8] + "/" + startdate[4:6] + "/" + startdate[0:4]
  dt = datetime.strptime(strdate,"%d/%m/%Y")
  numday = int(dt.strftime("%w"))
  if numday == 1:
    strdate = "Maandag - " + strdate
  if numday == 2:
    strdate = "Dinsdag - " + strdate
  if numday == 3:
    strdate = "Woensdag - " + strdate
  if numday == 4:
    strdate = "Donderdag - " + strdate
  if numday == 5:
    strdate = "Vrijdag - " + strdate
  if numday == 6:
    strdate = "Zaterdag - " + strdate
  if numday == 0:
    strdate = "Zondag - " + strdate

#  print("------------------------------------------------")
#  print(dta_description[:150])
#  print(strdate)
#  print(strtime)
#  print(starttime)
#  print(stoptime)
  f.write("      <table><tr id='titel'><th width=1800px>" + strdate +  " - " +  str(starttime) + " => " + str(stoptime) + "<BR CLEAR=ALL><font color='#FFFFAA'><font size='+1'><B><A HREF='" + HA_LinkURL +  "api/webhook/epgcalendarqOOYo8Ifn57Tjvh1KMiy6Is?message=" + str(dta_recid) + "' TARGET='leftx'>" + dta_title + "</A></B></font></td><td style='width:15%;'><img src= '" + LOGOFolder + dta_logo.strip() + "' height=25px></th></tr></table> \n")
  f.write("      <table><tr id='even'><td width=2000px>"+ dta_channel + " <font color='#FFAAAA'>(" +strtime + ")</font><br clear=all><br clear=all>")
  if len(dta_subtitle.strip()) > 1:
    f.write("(" + dta_subtitle + ")<br clear=all>")
  if len(dta_description.strip()) > 1:
    f.write(dta_description)
  else:
    f.write(dta_title)
  if len(dta_episode.strip()) > 1:
    f.write("<br clear=all><br clear=all>Episode:" + dta_episode)
  f.write("</td></tr></table>")


#<td style='width:" + str(int(drawpixels)) + "px;vertical-align: top;'><B><font color='#FFFF88'>" + dta_title + "</font></B><BR CLEAR=ALL>" \
#        + "<font color='#AAAAFF'>" + starttime + " - " + stoptime +  "</font> " \
#        + "<font color='#FFAAAA'>(" + strtime + ")</font><BR CLEAR=ALL>" \
#        + "<font size='-1'>" + dta_description[:150] + dots + "</font></td>")

  #--- END: FOOTER ---
f.write("    </div></div>                                                                             \n" \
      + "</BODY>                                                                                      \n" \
      + "</HTML>                                                                                      \n")
f.close()

#--- @@@ THE END - CLEAUP @@@ ---
conn.close()

